package com.example.tourist;

public class QuestionAndAnswer {
    public static String question []={
            "which company owns the android?",
            "which one is not programming language?",
            "where are you watching this video?",
            "What is part of a database that holds only one type of information",
            "  '.MOV' extension refers usually to what kind of file? "


    };
    public static String choices [] []={
            {"Google","Nokia","Samsung","Apple"},
            {"Java","Kotlin","HTML","PHP"},
            {"Facebook","Instagram","Whatsapp","Youtube"},
            {"Report" , "Field", "Record", "File"},
            {"Image file","Animation/movie file","Audio file","MS Office document"}

    };
    public static String correctAnswers []={
            "Google",
            "HTML",
            "Facebook",
            "Field",
            "Animation/movie file"


    };
}
